#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

#include "sysinfo.h"
uint64
sys_exit(void)
{
  int n;
  if(argint(0, &n) < 0)
    return -1;
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  if(argaddr(0, &p) < 0)
    return -1;
  return wait(p);
}

uint64
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

//在kernel/sysproc.c中添加sys_trace()函数，
//该函数通过在进程结构中的新变量中记住其参数来实现新的系统调用(参见kernel/proc.h)。
//从用户空间检索系统调用参数的函数在kernel/syscall.c中，您可以在kernel/ sysprocess .c中看到它们的使用示例。
uint64
sys_trace(void)
{
    int mask;
    if(argint(0, &mask)<0)
        return -1;
    // printf("sys_trace:%d\n",mask);
    myproc()->mask=mask;
    return 0;
}

uint64
sys_sysinfo(void)
{
    struct sysinfo sinfo;
    struct proc *p = myproc();
    //获取地址
    uint64 addr;
    if(argaddr(0,&addr)<0)
        return -1;
    //下面就是对这个结构体进行填充
    // uint64 freemem;   // amount of free memory (bytes)
    // uint64 nproc;     // number of process
    sinfo.freemem=sys_freemem();
    sinfo.nproc=sys_nproc();
    //返回给用户
    if(copyout(p->pagetable, addr, (char *)&sinfo, sizeof(sinfo)) < 0)
      return -1;
    // printf("sys_sysinfo:add: info=%d\n",addr);
    return 0;
}

